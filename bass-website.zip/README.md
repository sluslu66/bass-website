# Bass Vibes Website 🎸

Simple static website themed around bass guitar.

## Features
- Clean dark UI
- Bass-themed content
- Easy to deploy

## How to use
Just open index.html in your browser.

## Author
You
